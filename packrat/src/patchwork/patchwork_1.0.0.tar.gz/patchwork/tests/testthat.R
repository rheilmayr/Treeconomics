library(testthat)
library(patchwork)

test_check("patchwork")
