library(testthat)
library(sjmisc)

test_check("sjmisc")
