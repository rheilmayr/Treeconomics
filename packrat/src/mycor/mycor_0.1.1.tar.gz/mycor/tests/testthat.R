library(testthat)
library(mycor)

test_check("mycor")
