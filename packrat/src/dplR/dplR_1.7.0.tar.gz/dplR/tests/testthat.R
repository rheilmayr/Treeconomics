if (require("testthat", character.only = TRUE)) {
    test_check("dplR")
}
