plotRings <- function(...) {
  .Defunct(msg = "'plotRings' has been removed from this package and is being developed as its own package")
}

