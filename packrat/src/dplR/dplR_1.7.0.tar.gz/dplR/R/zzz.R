.onUnload <- function (libpath) {
    library.dynam.unload("dplR", libpath)
}
